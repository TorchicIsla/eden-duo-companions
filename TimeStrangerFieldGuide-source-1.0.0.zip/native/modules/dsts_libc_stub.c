// Link-time stand-in for Android's libc.so (only the names this module imports). Never shipped.
#include <stddef.h>
void* malloc(size_t n) { return 0; }
void* calloc(size_t a, size_t b) { return 0; }
void free(void* p) {}
void* memcpy(void* d, const void* s, size_t n) { return d; }
void* memset(void* d, int c, size_t n) { return d; }
