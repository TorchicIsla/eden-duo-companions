#!/usr/bin/env bash
set -euo pipefail
# Digimon Story Time Stranger (010062E01FE0C000): Android arm64 module, plain clang + lld (no NDK: the module
# uses only malloc/calloc/free/memcpy/memset from the system libc). Optional host test harness with sanitizers.
#   dsts_build.sh <eden-duo checkout> <output dir> [--test]
sdk_root="${1:?Eden Duo checkout required}"
output_dir="${2:?Output directory required}"
source_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p -- "$output_dir"
cat > "$output_dir/dsts.exports" <<'EXPORTS'
{ global: eden_dsmod_get_module; eden_dsmod_get_extensions; eden_dsmod_get_font_extensions; local: *; };
EXPORTS
T=--target=aarch64-linux-android24
clang $T -shared -nostdlib -fPIC -Wl,-soname,libc.so "$source_dir/dsts_libc_stub.c" -o "$output_dir/libc.so"
clang++ $T -std=c++17 -O2 -fPIC -shared -nostdlib -fno-exceptions -fno-rtti -fno-builtin-malloc \
  -fvisibility=hidden -fno-stack-protector -ffreestanding -fuse-ld=lld -I"$sdk_root/src" \
  -Wl,--version-script="$output_dir/dsts.exports" -Wl,--no-undefined -Wl,-z,noexecstack -Wl,--hash-style=both \
  -Wl,-soname,010062E01FE0C000.so "$source_dir/010062E01FE0C000.cpp" "$output_dir/libc.so" \
  -o "$output_dir/010062E01FE0C000.so"
llvm-strip --strip-unneeded "$output_dir/010062E01FE0C000.so" 2>/dev/null || true
if [ "${3:-}" = "--test" ]; then
  # dsts_test --file app_text01.nx64.mvgl=<path> --font out.txt --image module:dsts:font out.bin ...
  "${CXX:-g++}" -std=c++17 -O1 -g -fsanitize=address,undefined -DDSTS_HOST_TEST -I"$sdk_root/src" \
    "$source_dir/010062E01FE0C000.cpp" -o "$output_dir/dsts_test"
fi
