# Digimon Story Time Stranger: Time Stranger Field Guide

Generator for `010062E01FE0C000-TimeStrangerFieldGuide-<version>.dsmod.zip` (game update 1.2.2,
build `135C83CDEA06AEC2`). Native module: `native/modules/010062E01FE0C000.cpp`.

No game text or art is kept here. The guide's own notes (missions, side quests, dex, locations, bosses,
item data) are in `guide_data.tok.json`, where every piece of game text is a token (a hash, never the
text). The build fills the tokens in from your own copy of the game, then takes the game text out of the
package again: labels hold references that the module resolves at run time from the player's files.

## Build

```sh
# 1. The game's English text tables, from your own dump (romfs folder or the archive itself)
python3 dump_text.py <romfs>/app_text01.nx64.mvgl -o text122.json

# 2. The native module (clang + lld, arm64 Android; --test also builds the host test harness)
bash ../../native/modules/dsts_build.sh <eden-duo checkout> build

# 3. The package
DSTS_TEXT_JSON=text122.json DSTS_MODULE_SO=build/010062E01FE0C000.so \
  python3 build_dsts_package.py 010062E01FE0C000 --public
```

The result is byte-for-byte the released package (apart from the module's build ID). Needs Python 3 with
Pillow and NumPy.

| File | What it is |
|---|---|
| `build_dsts_package.py` | Pages, memory points, layout, art and packaging |
| `public_text.py` | Takes game text out of the manifest (references the module fills in) |
| `guidedata.py`, `guide_data.tok.json` | The guide's data with game text as tokens |
| `bgart.py` | Backgrounds, location bar and other art, drawn from code |
| `dump_text.py`, `expa.py` | Read the game's text tables (MDB1 archive, EXPA tables) from your own files |
| `rbpaths.py` | Area name lookup helpers |
| `tokenize_data.py` | Author tool: re-tokenizes the working data files |
